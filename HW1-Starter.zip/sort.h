/* Do NOT modify this file */

#ifndef _SORT_H_
#define _SORT_H_

#include <stdio.h>
#include <stdbool.h>

/* Selection sort
   Parameters:
   arr: array to sort
   size: size of array
   sorted array is left in arr
*/
void ssort(int * arr, int size);

#endif
